 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aldo.pcs_2001082033;
import static spark.Spark.*;
/**
 *
 * @author Aldo
 */
public class Main {
    public static void main(String[] args) {
        get("/hello", (req,res) -> "Selamat Datang");
        get("/hello/:name", (req,res) ->{
            return "Hello, "+ req.params(":name");
        });
    }
    
}
