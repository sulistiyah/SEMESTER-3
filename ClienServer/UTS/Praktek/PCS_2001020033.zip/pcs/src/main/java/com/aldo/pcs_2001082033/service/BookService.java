/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aldo.pcs_2001082033.service;

import com.aldo.pcs_2001082033.model.Book;
import com.aldo.pcs_2001082033.model.User;
import java.util.Collection;

/**
 *
 * @author Aldo
 */
public interface BookService {
    public void addBook (Book book);
    public Collection<Book> getBook();
    public Book getBook(String id);
    public Book editBook(Book book);
    public void deleteBook(String id);
    public boolean bookExist(String id);

}
