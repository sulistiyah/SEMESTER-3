/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aldo.pcs_2001082033.model;

/**
 *
 * @author Aldo
 */
public class Mahasiswa {
    private String id;
    private String no_bp;
    private String nama;
    private String alamat;
    private String jenis_kelamin;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNo_bp() {
        return no_bp;
    }

    public void setNo_bp(String no_bp) {
        this.no_bp = no_bp;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getJenis_kelamin() {
        return jenis_kelamin;
    }

    public void setJenis_kelamin(String jenis_kelamin) {
        this.jenis_kelamin = jenis_kelamin;
    }
    
}
