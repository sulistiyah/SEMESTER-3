/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aldo.pcs_2001082033.service;

import com.aldo.pcs_2001082033.model.User;
import com.aldo.pcs_2001082033.model.Book;
import com.aldo.pcs_2001082033.model.Mahasiswa;
import java.util.Collection;
import java.util.HashMap;
import java.util.Objects;

/**
 *
 * @author Aldo
 */
public class MahasiswaServiceImpl implements MahasiswaService {
    private HashMap<String, Mahasiswa> userMap;
    
    public MahasiswaServiceImpl() {
        userMap = new HashMap<>();
        Mahasiswa mahasiswa = new Mahasiswa();
        mahasiswa.setId("1");
        mahasiswa.setNo_bp("2001082033");
        mahasiswa.setNama("Aldo Spama Putra Suir");
        mahasiswa.setAlamat("Padang");
        mahasiswa.setJenis_kelamin("Lakik");
        userMap.put(mahasiswa.getId(), mahasiswa);
    }

    @Override
    public void addMahasiswa(Mahasiswa mahasiswa) {
        userMap.put(mahasiswa.getId(), mahasiswa);
    }

    @Override
    public Collection<Mahasiswa> getMahasiswa() {
       return userMap.values();
    }

    @Override
    public Mahasiswa getMahasiswa(String id) {
        return userMap.get(id);
    }

    @Override
    public Mahasiswa editMahasiswa(Mahasiswa mahasiswa) {
        Mahasiswa mahasiswaEdit = userMap.get(mahasiswa.getId());
        mahasiswaEdit.setNo_bp(mahasiswa.getNo_bp());
        mahasiswaEdit.setNama(mahasiswa.getNama());
        mahasiswaEdit.setAlamat(mahasiswa.getAlamat());
        mahasiswaEdit.setJenis_kelamin(mahasiswa.getJenis_kelamin());
        return mahasiswaEdit;
    }

    @Override
    public void deletedMahasiswa(String id) {
       userMap.remove(id);
    }

    @Override
    public boolean mahasiswaExist(String id) {
       return userMap.containsKey(id);
    }
    
    
    
}
