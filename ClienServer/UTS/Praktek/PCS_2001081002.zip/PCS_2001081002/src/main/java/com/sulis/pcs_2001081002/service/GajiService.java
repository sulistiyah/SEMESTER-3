/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.pcs_2001081002.service;

import com.sulis.pcs_2001081002.model.Gaji;
import java.util.Collection;

/**
 *
 * @author Sulis Tiyah
 */
public interface GajiService {
    public void addGaji (Gaji gaji);
    public Collection<Gaji> getGaji();
    public Gaji getGaji(String id);
    public Gaji editGaji(Gaji gaji);
    public void deleteGaji(String id);
    public boolean gajiExist(String id);

    public Object getgaji();
    
}
