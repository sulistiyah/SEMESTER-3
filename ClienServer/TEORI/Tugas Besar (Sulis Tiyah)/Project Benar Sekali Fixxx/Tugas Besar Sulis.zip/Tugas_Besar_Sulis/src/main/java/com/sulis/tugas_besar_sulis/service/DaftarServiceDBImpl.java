/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Daftar;
import java.util.List;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class DaftarServiceDBImpl implements DaftarServiceDB{
     private final Sql2o sql2o;
    
    public DaftarServiceDBImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void addDaftar(Daftar daftar) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("insert into daftar(nama, email, username, password, re_password) "
                    + "VALUES (:nama, :email, :username, :password, :re_password)")
                    .addParameter("nama", daftar.getNama())
                    .addParameter("email", daftar.getEmail())
                    .addParameter("username",daftar.getUsername())
                    .addParameter("password",daftar.getPassword())
                    .addParameter("re_password",daftar.getRe_password())
                    .executeUpdate();
            conn.commit();
        }
    }

    @Override
    public List<Daftar> getDaftar() {
       try (Connection conn = sql2o.open()) {
            List<Daftar> daftar = conn.createQuery("select * from daftar")
                    .executeAndFetch(Daftar.class);
            return daftar;
        }
    }

    @Override
    public Daftar getDaftar(String username) {
         try (Connection conn = sql2o.open()) {
            Daftar daftar= conn.createQuery("select * from daftar where username=:username")
                    .addParameter("username", username)
                    .executeAndFetchFirst(Daftar.class);
            return daftar;
        }
    }

    @Override
    public Daftar editDaftar(Daftar daftar) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("update daftar set nama=:nama,"
                    + "email=:email, password=:password, re_password=:re_password where username=:username")
                    .addParameter("nama", daftar.getNama())
                    .addParameter("email", daftar.getEmail())
                    .addParameter("username",daftar.getUsername())
                    .addParameter("password",daftar.getPassword())
                    .addParameter("re_password",daftar.getRe_password())
                    .executeUpdate();
            conn.commit();
        }
        return daftar;
    }

    @Override
    public void deletedDaftar(String username) {
        try (Connection conn = sql2o.open()) {
            conn.createQuery("delete from daftar where username=:username")
                    .addParameter("username", username)
                    .executeUpdate();
        }
    }

   @Override
    public boolean daftarExist(String username) {
       try (Connection conn = sql2o.open()) {
            List<Daftar> daftar = conn.createQuery("select * from daftar username=:username")
                    .addParameter("username", username)
                    .executeAndFetch(Daftar.class);
            return daftar.size() > 0;
        }
    }
   
    
}