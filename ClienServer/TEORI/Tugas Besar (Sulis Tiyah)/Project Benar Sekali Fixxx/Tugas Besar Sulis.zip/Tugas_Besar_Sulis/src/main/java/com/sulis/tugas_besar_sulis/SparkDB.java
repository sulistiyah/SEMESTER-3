/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis;

import com.google.gson.Gson;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import com.sulis.tugas_besar_sulis.model.Daftar;
import com.sulis.tugas_besar_sulis.model.Login;
import com.sulis.tugas_besar_sulis.model.Form_Mahasiswa;
import com.sulis.tugas_besar_sulis.model.Hasil_Form_Mahasiswa;
import com.sulis.tugas_besar_sulis.response.StandardResponse;
import com.sulis.tugas_besar_sulis.response.StatusResponse;
import com.sulis.tugas_besar_sulis.service.DaftarServiceDB;
import com.sulis.tugas_besar_sulis.service.DaftarServiceDBImpl;
import com.sulis.tugas_besar_sulis.service.LoginServiceDB;
import com.sulis.tugas_besar_sulis.service.LoginServiceDBImpl;
import com.sulis.tugas_besar_sulis.service.Form_MahasiswaServiceDB;
import com.sulis.tugas_besar_sulis.service.Form_MahasiswaServiceDBImpl;
import com.sulis.tugas_besar_sulis.service.Hasil_Form_MahasiswaServiceDB;
import com.sulis.tugas_besar_sulis.service.Hasil_Form_MahasiswaServiceDBImpl;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.sql2o.Sql2o;
import static spark.Spark.delete;
import static spark.Spark.get;
import static spark.Spark.post;
import static spark.Spark.put;


/**
 *
 * @author Sulis Tiyah
 */
public class SparkDB {
     public static void main(String[] args) {
        try {
            Sql2o sql2o = new Sql2o(getDataSource());
            
            final DaftarServiceDB daftarService = new DaftarServiceDBImpl(sql2o);
                post("/daftar", (request, response) -> {
                    response.type("application/json");

                    Daftar daftar = new Gson().fromJson(request.body(), Daftar.class);
                    daftarService.addDaftar(daftar);

                    return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
                });
            
            final LoginServiceDB loginService = new LoginServiceDBImpl(sql2o);
                post("/login", (request, response) -> {
                    response.type("application/json");

                    Login login = new Gson().fromJson(request.body(), Login.class);
                    loginService.addLogin(login);

                    return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
                });
            
            final Form_MahasiswaServiceDB form_MahasiswaService = new Form_MahasiswaServiceDBImpl(sql2o);   
                post("/form_mahasiswa", (request, response) -> {
                response.type("application/json");
            
                Form_Mahasiswa form_Mahasiswa = new Gson().fromJson(request.body(), Form_Mahasiswa.class);
                form_MahasiswaService.addForm_Mahasiswa(form_Mahasiswa);

                return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
                });

                get("/form_mahasiswa", (request, response) -> {
                    response.type("application/json");
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.SUCCESS,new Gson().toJsonTree(form_MahasiswaService.getForm_Mahasiswa())));
                });

                get("/form_mahasiswa/:no_bp", (request, response) -> {
                    response.type("application/json");
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.SUCCESS,
                                    new Gson().toJsonTree(
                                            form_MahasiswaService.getForm_Mahasiswa(request.params(":no_bp"))
                                    )
                            )
                    );
                });

                put("/form_mahasiswa/:no_bp", (request, response) -> {
                    response.type("application/json");
                    Form_Mahasiswa toEdit = new Gson().fromJson(request.body(), Form_Mahasiswa.class);
                    Form_Mahasiswa editForm_Mahasiswa = form_MahasiswaService.editForm_Mahasiswa(toEdit);
                    if (editForm_Mahasiswa != null) {
                        return new Gson().toJson(
                                new StandardResponse(StatusResponse.SUCCESS,
                                        new Gson().toJsonTree(editForm_Mahasiswa)));
                    } else {
                        return new Gson().toJson(
                                new StandardResponse(StatusResponse.ERROR,
                                        new Gson().toJson("Form Mahasiswa not found or error in edit")));
                    }
                });

                delete("/form_mahasiswa/:no_bp", (request, response) -> {
                    response.type("application/json");
                    form_MahasiswaService.deletedForm_Mahasiswa(request.params(":no_bp"));
                    return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS, "Data Form Mahasiswa deleted"));
                });
            final Hasil_Form_MahasiswaServiceDB hasil_Form_MahasiswaService = new Hasil_Form_MahasiswaServiceDBImpl(sql2o);   
                post("/hasil_form_mahasiswa", (request, response) -> {
                response.type("application/json");
            
                Hasil_Form_Mahasiswa hasil_Form_Mahasiswa = new Gson().fromJson(request.body(), Hasil_Form_Mahasiswa.class);
                hasil_Form_MahasiswaService.addHasil_Form_Mahasiswa(hasil_Form_Mahasiswa);

                return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
                });

                get("/hasil_form_mahasiswa", (request, response) -> {
                    response.type("application/json");
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.SUCCESS,new Gson().toJsonTree(hasil_Form_MahasiswaService.getHasil_Form_Mahasiswa())));
                });

                get("/hasil_form_mahasiswa/:no_bp", (request, response) -> {
                    response.type("application/json");
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.SUCCESS,
                                    new Gson().toJsonTree(
                                            hasil_Form_MahasiswaService.getHasil_Form_Mahasiswa(request.params(":no_bp"))
                                    )
                            )
                    );
                });

                put("/hasil_form_mahasiswa/:no_bp", (request, response) -> {
                    response.type("application/json");
                    Hasil_Form_Mahasiswa toEdit = new Gson().fromJson(request.body(), Hasil_Form_Mahasiswa.class);
                    Hasil_Form_Mahasiswa editHasil_Form_Mahasiswa = hasil_Form_MahasiswaService.editHasil_Form_Mahasiswa(toEdit);
                    if (editHasil_Form_Mahasiswa != null) {
                        return new Gson().toJson(
                                new StandardResponse(StatusResponse.SUCCESS,
                                        new Gson().toJsonTree(editHasil_Form_Mahasiswa)));
                    } else {
                        return new Gson().toJson(
                                new StandardResponse(StatusResponse.ERROR,
                                        new Gson().toJson("Hasil Form Mahasiswa not found or error in edit")));
                    }
                });

                delete("/hasil_form_mahasiswa/:no_bp", (request, response) -> {
                    response.type("application/json");
                    hasil_Form_MahasiswaService.deletedHasil_Form_Mahasiswa(request.params(":no_bp"));
                    return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS, "Data Hasil Form Mahasiswa deleted"));
                });    

            
        } catch (SQLException ex) {
            Logger.getLogger(SparkDB.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }

    public static DataSource getDataSource() throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setDatabaseName("pcs_sulis");
        dataSource.setServerName("localhost");
        dataSource.setPort(3306);
        dataSource.setUser("root");
        dataSource.setPassword("");
        dataSource.setServerTimezone("UTC");
        return dataSource;
    }
}
