/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Form_Mahasiswa;
import java.util.Collection;
import java.util.HashMap;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class Form_MahasiswaServiceImpl implements Form_MahasiswaService{
    private HashMap<String, Form_Mahasiswa> form_mahasiswaMap;
    private final Sql2o sql2o;
    
    public Form_MahasiswaServiceImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
        form_mahasiswaMap = new HashMap<>();
        Form_Mahasiswa form_Mahasiswa = new Form_Mahasiswa();
        form_Mahasiswa.setNo_bp("2001081002");
        form_Mahasiswa.setNama_lengkap("Sulis Tiyah");
        form_Mahasiswa.setJurusan("Teknologi Informasi");
        form_Mahasiswa.setProdi("D3 Teknik Komputer");
        form_Mahasiswa.setTempat_tanggal_lahir("Gunung Raja, 03 Desember 2002");
        form_Mahasiswa.setJenis_kelamin("Perempuan");
        form_Mahasiswa.setAgama("Islam");
        form_Mahasiswa.setNo_telp("081292323052");
        form_Mahasiswa.setAlamat("Muara Enim, Sumatera Selatan");
        form_mahasiswaMap.put(form_Mahasiswa.getNo_bp(), form_Mahasiswa);
    }

    @Override
    public void addForm_Mahasiswa(Form_Mahasiswa form_Mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
        form_mahasiswaMap.put(form_Mahasiswa.getNo_bp(), form_Mahasiswa);
        }
    }

    @Override
    public Collection<Form_Mahasiswa> getForm_Mahasiswa() {
       return form_mahasiswaMap.values();
    }

    @Override
    public Form_Mahasiswa getForm_Mahasiswa(String no_bp) {
        return form_mahasiswaMap.get(no_bp);
    }

    @Override
    public Form_Mahasiswa editForm_Mahasiswa(Form_Mahasiswa form_Mahasiswa) {
        Form_Mahasiswa form_mahasiswaEdit = form_mahasiswaMap.get(form_Mahasiswa.getNo_bp());
        form_mahasiswaEdit.setNama_lengkap(form_Mahasiswa.getNama_lengkap());
        form_mahasiswaEdit.setJurusan(form_Mahasiswa.getJurusan());
        form_mahasiswaEdit.setProdi(form_Mahasiswa.getProdi());
        form_mahasiswaEdit.setTempat_tanggal_lahir(form_Mahasiswa.getTempat_tanggal_lahir());
        form_mahasiswaEdit.setJenis_kelamin(form_Mahasiswa.getJenis_kelamin());
        form_mahasiswaEdit.setAgama(form_Mahasiswa.getAgama());
        form_mahasiswaEdit.setNo_telp(form_Mahasiswa.getNo_telp());
        form_mahasiswaEdit.setAlamat(form_Mahasiswa.getAlamat());
        return form_mahasiswaEdit;
    }

    @Override
    public void deletedForm_Mahasiswa(String no_bp) {
       form_mahasiswaMap.remove(no_bp);
    }

    @Override
    public boolean form_MahasiswaExist(String no_bp) {
       return form_mahasiswaMap.containsKey(no_bp);
    }

    
}
