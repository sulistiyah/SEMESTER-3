/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Form_Mahasiswa;
import java.util.Collection;

/**
 *
 * @author Sulis Tiyah
 */
public interface Form_MahasiswaService {
    public void addForm_Mahasiswa (Form_Mahasiswa form_Mahasiswa);
    public Collection<Form_Mahasiswa> getForm_Mahasiswa();
    public Form_Mahasiswa getForm_Mahasiswa(String no_bp);
    public Form_Mahasiswa editForm_Mahasiswa(Form_Mahasiswa form_Mahasiswa);
    public void deletedForm_Mahasiswa(String no_bp);
    public boolean form_MahasiswaExist(String no_bp);
        
}
