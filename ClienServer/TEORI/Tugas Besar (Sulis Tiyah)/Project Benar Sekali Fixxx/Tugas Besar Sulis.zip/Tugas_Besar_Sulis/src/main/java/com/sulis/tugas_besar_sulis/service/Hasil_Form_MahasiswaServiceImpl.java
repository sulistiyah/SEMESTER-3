/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Hasil_Form_Mahasiswa;
import java.util.Collection;
import java.util.HashMap;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class Hasil_Form_MahasiswaServiceImpl implements Hasil_Form_MahasiswaService{
    private HashMap<String, Hasil_Form_Mahasiswa> hasil_form_mahasiswaMap;
    private final Sql2o sql2o;
    
    public Hasil_Form_MahasiswaServiceImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
        hasil_form_mahasiswaMap = new HashMap<>();
        Hasil_Form_Mahasiswa hasil_Form_Mahasiswa = new Hasil_Form_Mahasiswa();
        hasil_Form_Mahasiswa.setNo_bp("2001081002");
        hasil_Form_Mahasiswa.setNama_lengkap("Sulis Tiyah");
        hasil_Form_Mahasiswa.setJurusan("Teknologi Informasi");
        hasil_Form_Mahasiswa.setProdi("D3 Teknik Komputer");
        hasil_Form_Mahasiswa.setTempat_tanggal_lahir("Gunung Raja, 03 Desember 2002");
        hasil_Form_Mahasiswa.setJenis_kelamin("Perempuan");
        hasil_Form_Mahasiswa.setAgama("Islam");
        hasil_Form_Mahasiswa.setNo_telp("081292323052");
        hasil_Form_Mahasiswa.setAlamat("Muara Enim, Sumatera Selatan");
        hasil_form_mahasiswaMap.put(hasil_Form_Mahasiswa.getNo_bp(), hasil_Form_Mahasiswa);
    }

    @Override
    public void addHasil_Form_Mahasiswa(Hasil_Form_Mahasiswa hasil_Form_Mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
        hasil_form_mahasiswaMap.put(hasil_Form_Mahasiswa.getNo_bp(), hasil_Form_Mahasiswa);
        }
    }

    @Override
    public Collection<Hasil_Form_Mahasiswa> getHasil_Form_Mahasiswa() {
       return hasil_form_mahasiswaMap.values();
    }

    @Override
    public Hasil_Form_Mahasiswa getHasil_Form_Mahasiswa(String no_bp) {
        return hasil_form_mahasiswaMap.get(no_bp);
    }

    @Override
    public Hasil_Form_Mahasiswa editHasil_Form_Mahasiswa(Hasil_Form_Mahasiswa hasil_Form_Mahasiswa) {
        Hasil_Form_Mahasiswa hasil_form_mahasiswaEdit = hasil_form_mahasiswaMap.get(hasil_Form_Mahasiswa.getNo_bp());
        hasil_form_mahasiswaEdit.setNama_lengkap(hasil_Form_Mahasiswa.getNama_lengkap());
        hasil_form_mahasiswaEdit.setJurusan(hasil_Form_Mahasiswa.getJurusan());
        hasil_form_mahasiswaEdit.setProdi(hasil_Form_Mahasiswa.getProdi());
        hasil_form_mahasiswaEdit.setTempat_tanggal_lahir(hasil_Form_Mahasiswa.getTempat_tanggal_lahir());
        hasil_form_mahasiswaEdit.setJenis_kelamin(hasil_Form_Mahasiswa.getJenis_kelamin());
        hasil_form_mahasiswaEdit.setAgama(hasil_Form_Mahasiswa.getAgama());
        hasil_form_mahasiswaEdit.setNo_telp(hasil_Form_Mahasiswa.getNo_telp());
        hasil_form_mahasiswaEdit.setAlamat(hasil_Form_Mahasiswa.getAlamat());
        return hasil_form_mahasiswaEdit;
    }

    @Override
    public void deletedHasil_Form_Mahasiswa(String no_bp) {
       hasil_form_mahasiswaMap.remove(no_bp);
    }

    @Override
    public boolean hasil_Form_MahasiswaExist(String no_bp) {
       return hasil_form_mahasiswaMap.containsKey(no_bp);
    }
    
}
