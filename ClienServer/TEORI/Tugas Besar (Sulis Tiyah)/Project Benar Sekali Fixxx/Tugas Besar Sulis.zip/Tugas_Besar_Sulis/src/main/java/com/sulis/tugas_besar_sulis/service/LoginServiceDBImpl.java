/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Login;
import java.util.List;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class LoginServiceDBImpl implements LoginServiceDB{
    private final Sql2o sql2o;
    
    public LoginServiceDBImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void addLogin(Login login) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("insert into login(username,password) "
                    + "VALUES (:username, :password)")
                    .addParameter("username", login.getUsername())
                    .addParameter("password", login.getPassword())
                    .executeUpdate();
            conn.commit();
        }
    }

    @Override
    public List<Login> getLogin() {
       try (Connection conn = sql2o.open()) {
            List<Login> login = conn.createQuery("select * from login")
                    .executeAndFetch(Login.class);
            return login;
        }
    }

    @Override
    public Login getLogin(String username) {
         try (Connection conn = sql2o.open()) {
            Login login= conn.createQuery("select * from login where username=:username")
                    .addParameter("username", username)
                    .executeAndFetchFirst(Login.class);
            return login;
        }
    }

    @Override
    public Login editLogin(Login login) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("update login set password=:password where username=:username")
                    .addParameter("username", login.getUsername())
                    .addParameter("password", login.getPassword())
                    .executeUpdate();
            conn.commit();
        }
        return login;
    }

    @Override
    public void deletedLogin(String username) {
        try (Connection conn = sql2o.open()) {
            conn.createQuery("delete from login where username=:username")
                    .addParameter("username", username)
                    .executeUpdate();
        }
    }

    @Override
    public boolean loginExist(String username) {
       try (Connection conn = sql2o.open()) {
            List<Login> login = conn.createQuery("select * from mahasiswa username=:username")
                    .addParameter("username", username)
                    .executeAndFetch(Login.class);
            return login.size() > 0;
        }
    }
   

    
}
