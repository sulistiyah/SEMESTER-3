/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Hasil_Form_Mahasiswa;
import java.util.List;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class Hasil_Form_MahasiswaServiceDBImpl implements Hasil_Form_MahasiswaServiceDB{
    private final Sql2o sql2o;
    
    public Hasil_Form_MahasiswaServiceDBImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void addHasil_Form_Mahasiswa(Hasil_Form_Mahasiswa hasil_Form_Mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("insert into hasil_form_mahasiswa(no_bp, nama_lengkap, jurusan, prodi, tempat_tanggal_lahir, jenis_kelamin, agama, no_telp, alamat) "
                    + "VALUES (:no_bp, :nama_lengkap, :jurusan, :prodi, :tempat_tanggal_lahir, :jenis_kelamin, :agama, :no_telp, :alamat)")
                    .addParameter("no_bp", hasil_Form_Mahasiswa.getNo_bp())
                    .addParameter("nama_lengkap", hasil_Form_Mahasiswa.getNama_lengkap())
                    .addParameter("jurusan",hasil_Form_Mahasiswa.getJurusan())
                    .addParameter("prodi",hasil_Form_Mahasiswa.getProdi())
                    .addParameter("tempat_tanggal_lahir",hasil_Form_Mahasiswa.getTempat_tanggal_lahir())
                    .addParameter("jenis_kelamin", hasil_Form_Mahasiswa.getJenis_kelamin())
                    .addParameter("agama", hasil_Form_Mahasiswa.getAgama())
                    .addParameter("no_telp", hasil_Form_Mahasiswa.getNo_telp())
                    .addParameter("alamat", hasil_Form_Mahasiswa.getAlamat())
                    .executeUpdate();
            conn.commit();
        }
    }

    @Override
    public List<Hasil_Form_Mahasiswa> getHasil_Form_Mahasiswa() {
       try (Connection conn = sql2o.open()) {
            List<Hasil_Form_Mahasiswa> hasil_Form_Mahasiswa = conn.createQuery("select * from hasil_form_mahasiswa")
                    .executeAndFetch(Hasil_Form_Mahasiswa.class);
            return hasil_Form_Mahasiswa;
        }
    }

    @Override
    public Hasil_Form_Mahasiswa getHasil_Form_Mahasiswa(String no_bp) {
         try (Connection conn = sql2o.open()) {
            Hasil_Form_Mahasiswa hasil_Form_Mahasiswa= conn.createQuery("select * from hasil_form_mahasiswa where no_bp=:no_bp")
                    .addParameter("no_bp", no_bp)
                    .executeAndFetchFirst(Hasil_Form_Mahasiswa.class);
            return hasil_Form_Mahasiswa;
        }
    }

    @Override
    public Hasil_Form_Mahasiswa editHasil_Form_Mahasiswa(Hasil_Form_Mahasiswa hasil_Form_Mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("update hasil_form_mahasiswa set nama_lengkap=:nama_lengkap,"
                    + "jurusan=:jurusan, prodi=:prodi, tempat_tanggal_lahir=:tempat_tanggal_lahir, jenis_kelamin=:jenis_kelamin, agama=:agama, no_telp=:no_telp, alamat=:alamat where no_bp=:no_bp")
                    .addParameter("no_bp", hasil_Form_Mahasiswa.getNo_bp())
                    .addParameter("nama_lengkap", hasil_Form_Mahasiswa.getNama_lengkap())
                    .addParameter("jurusan", hasil_Form_Mahasiswa.getJurusan())
                    .addParameter("prodi", hasil_Form_Mahasiswa.getProdi())
                    .addParameter("tempat_tanggal_lahir", hasil_Form_Mahasiswa.getTempat_tanggal_lahir())
                    .addParameter("jenis_kelamin", hasil_Form_Mahasiswa.getJenis_kelamin())
                    .addParameter("agama", hasil_Form_Mahasiswa.getAgama())
                    .addParameter("no_telp", hasil_Form_Mahasiswa.getNo_telp())
                    .addParameter("alamat", hasil_Form_Mahasiswa.getAlamat())
                    .executeUpdate();
            conn.commit();
        }
        return hasil_Form_Mahasiswa;
    }

    @Override
    public void deletedHasil_Form_Mahasiswa(String no_bp) {
        try (Connection conn = sql2o.open()) {
            conn.createQuery("delete from hasil_form_mahasiswa where no_bp=:no_bp")
                    .addParameter("no_bp", no_bp)
                    .executeUpdate();
        }
    }

    @Override
    public boolean hasil_Form_MahasiswaExist(String no_bp) {
       try (Connection conn = sql2o.open()) {
            List<Hasil_Form_Mahasiswa> hasil_Form_Mahasiswa= conn.createQuery("select * from hasil_form_mahasiswa no_bp=:no_bp")
                    .addParameter("no_bp", no_bp)
                    .executeAndFetch(Hasil_Form_Mahasiswa.class);
            return hasil_Form_Mahasiswa.size() > 0;
        }
    }
   
}
