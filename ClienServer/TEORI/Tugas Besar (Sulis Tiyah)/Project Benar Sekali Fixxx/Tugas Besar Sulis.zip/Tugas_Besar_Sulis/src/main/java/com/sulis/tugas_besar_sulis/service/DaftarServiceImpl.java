/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Daftar;
import java.util.Collection;
import java.util.HashMap;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Windo
 */
public class DaftarServiceImpl implements DaftarService{
     private HashMap<String, Daftar> daftarMap;
     private final Sql2o sql2o;
    
    public DaftarServiceImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
        daftarMap = new HashMap<>();
        Daftar daftar = new Daftar();
        daftar.setNama("Sulis Tiyah");
        daftar.setEmail("sulistyhm.03@gmail.com");
        daftar.setUsername("Sulistyh_");
        daftar.setPassword("12345");
        daftar.setRe_password("12345");
        daftarMap.put(daftar.getUsername(), daftar);
    }

    @Override
    public void addDaftar(Daftar daftar) {
        try (Connection conn = sql2o.beginTransaction()) {
        daftarMap.put(daftar.getUsername(), daftar);
        }
    }

    @Override
    public Collection<Daftar> getDaftar() {
       return daftarMap.values();
    }

    @Override
    public Daftar getDaftar(String username) {
        return daftarMap.get(username);
    }

    @Override
    public Daftar editDaftar(Daftar daftar) {
        Daftar daftarEdit = daftarMap.get(daftar.getUsername());
        daftarEdit.setNama(daftar.getNama());
        daftarEdit.setEmail(daftar.getEmail());
        daftarEdit.setPassword(daftar.getPassword());
        daftarEdit.setRe_password(daftar.getRe_password());
        return daftarEdit;
    }

    @Override
    public void deletedDaftar(String username) {
       daftarMap.remove(username);
    }

    @Override
    public boolean daftarExist(String username) {
       return daftarMap.containsKey(username);
    }

    
    
}
