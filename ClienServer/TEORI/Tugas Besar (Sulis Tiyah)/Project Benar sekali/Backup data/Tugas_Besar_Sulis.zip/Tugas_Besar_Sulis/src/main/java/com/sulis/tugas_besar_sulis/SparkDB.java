/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis;

import com.google.gson.Gson;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import com.sulis.tugas_besar_sulis.model.Daftar;
import com.sulis.tugas_besar_sulis.model.Login;
import com.sulis.tugas_besar_sulis.model.Mahasiswa;
import com.sulis.tugas_besar_sulis.response.StandardResponse;
import com.sulis.tugas_besar_sulis.response.StatusResponse;
import com.sulis.tugas_besar_sulis.service.DaftarServiceDB;
import com.sulis.tugas_besar_sulis.service.DaftarServiceDBImpl;
import com.sulis.tugas_besar_sulis.service.LoginServiceDB;
import com.sulis.tugas_besar_sulis.service.LoginServiceDBImpl;
import com.sulis.tugas_besar_sulis.service.MahasiswaServiceDB;
import com.sulis.tugas_besar_sulis.service.MahasiswaServiceDBImpl;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.sql2o.Sql2o;
import static spark.Spark.delete;
import static spark.Spark.get;
import static spark.Spark.post;
import static spark.Spark.put;

/**
 *
 * @author Sulis Tiyah
 */
public class SparkDB {
     public static void main(String[] args) {
        try {
            Sql2o sql2o = new Sql2o(getDataSource());
            
            final DaftarServiceDB daftarService = new DaftarServiceDBImpl(sql2o);
                post("/daftar", (request, response) -> {
                    response.type("application/json");

                    Daftar daftar = new Gson().fromJson(request.body(), Daftar.class);
                    daftarService.addDaftar(daftar);

                    return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
                });
            
            final LoginServiceDB loginService = new LoginServiceDBImpl(sql2o);
                post("/login", (request, response) -> {
                    response.type("application/json");

                    Login login = new Gson().fromJson(request.body(), Login.class);
                    loginService.addLogin(login);

                    return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
                });
            
            final MahasiswaServiceDB mahasiswaService = new MahasiswaServiceDBImpl(sql2o);   
                post("/mahasiswa", (request, response) -> {
                response.type("application/json");
            
                Mahasiswa mahasiswa = new Gson().fromJson(request.body(), Mahasiswa.class);
                mahasiswaService.addMahasiswa(mahasiswa);

                return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
                });

                get("/mahasiswa", (request, response) -> {
                    response.type("application/json");
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.SUCCESS,new Gson().toJsonTree(mahasiswaService.getMahasiswa())));
                });

                get("/mahasiswa/:no_bp", (request, response) -> {
                    response.type("application/json");
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.SUCCESS,
                                    new Gson().toJsonTree(
                                            mahasiswaService.getMahasiswa(request.params(":no_bp"))
                                    )
                            )
                    );
                });

                put("/mahasiswa/:no_bp", (request, response) -> {
                    response.type("application/json");
                    Mahasiswa toEdit = new Gson().fromJson(request.body(), Mahasiswa.class);
                    Mahasiswa editMahasiswa = mahasiswaService.editMahasiswa(toEdit);
                    if (editMahasiswa != null) {
                        return new Gson().toJson(
                                new StandardResponse(StatusResponse.SUCCESS,
                                        new Gson().toJsonTree(editMahasiswa)));
                    } else {
                        return new Gson().toJson(
                                new StandardResponse(StatusResponse.ERROR,
                                        new Gson().toJson("Mahasiswa not found or error in edit")));
                    }
                });

                delete("/mahasiswa/:no_bp", (request, response) -> {
                    response.type("application/json");
                    mahasiswaService.deletedMahasiswa(request.params(":no_bp"));
                    return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS, "Data Mahasiswa deleted"));
                });

            
        } catch (SQLException ex) {
            Logger.getLogger(SparkDB.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }

    public static DataSource getDataSource() throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setDatabaseName("pcs_sulis");
        dataSource.setServerName("localhost");
        dataSource.setPort(3306);
        dataSource.setUser("root");
        dataSource.setPassword("");
        dataSource.setServerTimezone("UTC");
        return dataSource;
    }
}
