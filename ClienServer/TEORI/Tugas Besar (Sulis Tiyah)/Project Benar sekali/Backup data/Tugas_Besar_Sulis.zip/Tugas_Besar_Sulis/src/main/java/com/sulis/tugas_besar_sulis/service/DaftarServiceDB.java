/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Daftar;
import java.util.List;

/**
 *
 * @author Windows
 */
public interface DaftarServiceDB {
    public void addDaftar (Daftar daftar);
    public List<Daftar> getDaftar();
    public Daftar getDaftar(String username);
    public Daftar editDaftar(Daftar daftar);
    public void deletedDaftar(String username);
    public boolean daftarExist(String username);
    
}
