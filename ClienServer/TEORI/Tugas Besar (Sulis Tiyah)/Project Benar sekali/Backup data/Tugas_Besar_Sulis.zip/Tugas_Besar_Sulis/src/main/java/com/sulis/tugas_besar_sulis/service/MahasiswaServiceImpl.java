/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Mahasiswa;
import java.util.Collection;
import java.util.HashMap;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class MahasiswaServiceImpl implements MahasiswaService{
    private HashMap<String, Mahasiswa> mahasiswaMap;
    private final Sql2o sql2o;
    
    public MahasiswaServiceImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
        mahasiswaMap = new HashMap<>();
        Mahasiswa mahasiswa = new Mahasiswa();
        mahasiswa.setNo_bp("2001081002");
        mahasiswa.setNama_lengkap("Sulis Tiyah");
        mahasiswa.setJurusan("Teknologi Informasi");
        mahasiswa.setProdi("D3 Teknik Komputer");
        mahasiswa.setTempat_tanggal_lahir("Gunung Raja, 03 Desember 2002");
        mahasiswa.setJenis_kelamin("Perempuan");
        mahasiswa.setAgama("Islam");
        mahasiswa.setNo_telp("081292323052");
        mahasiswa.setAlamat("Muara Enim, Sumatera Selatan");
        mahasiswaMap.put(mahasiswa.getNo_bp(), mahasiswa);
    }

    @Override
    public void addMahasiswa(Mahasiswa mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
        mahasiswaMap.put(mahasiswa.getNo_bp(), mahasiswa);
        }
    }

    @Override
    public Collection<Mahasiswa> getMahasiswa() {
       return mahasiswaMap.values();
    }

    @Override
    public Mahasiswa getMahasiswa(String no_bp) {
        return mahasiswaMap.get(no_bp);
    }

    @Override
    public Mahasiswa editMahasiswa(Mahasiswa mahasiswa) {
        Mahasiswa mahasiswaEdit = mahasiswaMap.get(mahasiswa.getNo_bp());
        mahasiswaEdit.setNama_lengkap(mahasiswa.getNama_lengkap());
        mahasiswaEdit.setJurusan(mahasiswa.getJurusan());
        mahasiswaEdit.setProdi(mahasiswa.getProdi());
        mahasiswaEdit.setTempat_tanggal_lahir(mahasiswa.getTempat_tanggal_lahir());
        mahasiswaEdit.setJenis_kelamin(mahasiswa.getJenis_kelamin());
        mahasiswaEdit.setAgama(mahasiswa.getAgama());
        mahasiswaEdit.setNo_telp(mahasiswa.getNo_telp());
        mahasiswaEdit.setAlamat(mahasiswa.getAlamat());
        return mahasiswaEdit;
    }

    @Override
    public void deletedMahasiswa(String no_bp) {
       mahasiswaMap.remove(no_bp);
    }

    @Override
    public boolean mahasiswaExist(String no_bp) {
       return mahasiswaMap.containsKey(no_bp);
    }

    
}
