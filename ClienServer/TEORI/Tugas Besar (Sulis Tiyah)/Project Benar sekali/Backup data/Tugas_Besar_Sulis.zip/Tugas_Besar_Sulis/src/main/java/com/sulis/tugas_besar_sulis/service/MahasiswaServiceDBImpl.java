/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Mahasiswa;
import java.util.List;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class MahasiswaServiceDBImpl implements MahasiswaServiceDB{
    private final Sql2o sql2o;
    
    public MahasiswaServiceDBImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void addMahasiswa(Mahasiswa mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("insert into mahasiswa(no_bp, nama_lengkap, jurusan, prodi, tempat_tanggal_lahir, jenis_kelamin, agama, no_telp, alamat) "
                    + "VALUES (:no_bp, :nama_lengkap, :jurusan, :prodi, :tempat_tanggal_lahir, :jenis_kelamin, :agama, :no_telp, :alamat)")
                    .addParameter("no_bp", mahasiswa.getNo_bp())
                    .addParameter("nama_lengkap", mahasiswa.getNama_lengkap())
                    .addParameter("jurusan",mahasiswa.getJurusan())
                    .addParameter("prodi",mahasiswa.getProdi())
                    .addParameter("tempat_tanggal_lahir",mahasiswa.getTempat_tanggal_lahir())
                    .addParameter("jenis_kelamin", mahasiswa.getJenis_kelamin())
                    .addParameter("agama", mahasiswa.getAgama())
                    .addParameter("no_telp", mahasiswa.getNo_telp())
                    .addParameter("alamat", mahasiswa.getAlamat())
                    .executeUpdate();
            conn.commit();
        }
    }

    @Override
    public List<Mahasiswa> getMahasiswa() {
       try (Connection conn = sql2o.open()) {
            List<Mahasiswa> mahasiswa = conn.createQuery("select * from mahasiswa")
                    .executeAndFetch(Mahasiswa.class);
            return mahasiswa;
        }
    }

    @Override
    public Mahasiswa getMahasiswa(String no_bp) {
         try (Connection conn = sql2o.open()) {
            Mahasiswa mahasiswa= conn.createQuery("select * from mahasiswa where no_bp=:no_bp")
                    .addParameter("no_bp", no_bp)
                    .executeAndFetchFirst(Mahasiswa.class);
            return mahasiswa;
        }
    }

    @Override
    public Mahasiswa editMahasiswa(Mahasiswa mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("update mahasiswa set nama_lengkap=:nama_lengkap,"
                    + "jurusan=:jurusan, prodi=:prodi, tempat_tanggal_lahir=:tempat_tanggal_lahir, jenis_kelamin=:jenis_kelamin, agama=:agama, no_telp=:no_telp, alamat=:alamat where no_bp=:no_bp")
                    .addParameter("no_bp", mahasiswa.getNo_bp())
                    .addParameter("nama_lengkap", mahasiswa.getNama_lengkap())
                    .addParameter("jurusan",mahasiswa.getJurusan())
                    .addParameter("prodi",mahasiswa.getProdi())
                    .addParameter("tempat_tanggal_lahir",mahasiswa.getTempat_tanggal_lahir())
                    .addParameter("jenis_kelamin", mahasiswa.getJenis_kelamin())
                    .addParameter("agama", mahasiswa.getAgama())
                    .addParameter("no_telp", mahasiswa.getNo_telp())
                    .addParameter("alamat", mahasiswa.getAlamat())
                    .executeUpdate();
            conn.commit();
        }
        return mahasiswa;
    }

    @Override
    public void deletedMahasiswa(String no_bp) {
        try (Connection conn = sql2o.open()) {
            conn.createQuery("delete from mahasiswa where no_bp=:no_bp")
                    .addParameter("no_bp", no_bp)
                    .executeUpdate();
        }
    }

    @Override
    public boolean mahasiswaExist(String no_bp) {
       try (Connection conn = sql2o.open()) {
            List<Mahasiswa> mahasiswa = conn.createQuery("select * from mahasiswa no_bp=:no_bp")
                    .addParameter("no_bp", no_bp)
                    .executeAndFetch(Mahasiswa.class);
            return mahasiswa.size() > 0;
        }
    }
   

    
}
