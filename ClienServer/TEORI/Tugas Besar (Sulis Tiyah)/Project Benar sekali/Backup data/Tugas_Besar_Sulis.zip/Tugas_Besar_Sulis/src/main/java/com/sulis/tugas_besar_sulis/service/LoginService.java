/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Login;
import java.util.Collection;

/**
 *
 * @author Sulis Tiyah
 */
public interface LoginService {
    public void addLogin (Login login);
    public Collection<Login> getLogin();
    public Login getLogin(String username);
    public Login editLogin(Login login);
    public void deletedLogin(String username);
    public boolean loginExist(String username);
}
