/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Mahasiswa;
import java.util.Collection;

/**
 *
 * @author Sulis Tiyah
 */
public interface MahasiswaService {
    public void addMahasiswa (Mahasiswa mahasiswa);
    public Collection<Mahasiswa> getMahasiswa();
    public Mahasiswa getMahasiswa(String no_bp);
    public Mahasiswa editMahasiswa(Mahasiswa mahasiswa);
    public void deletedMahasiswa(String no_bp);
    public boolean mahasiswaExist(String np_bp);
        
}
