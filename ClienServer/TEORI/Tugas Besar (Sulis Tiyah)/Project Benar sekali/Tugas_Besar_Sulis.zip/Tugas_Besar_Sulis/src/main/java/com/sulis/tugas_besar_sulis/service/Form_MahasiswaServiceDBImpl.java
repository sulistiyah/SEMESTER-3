/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Form_Mahasiswa;
import java.util.List;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class Form_MahasiswaServiceDBImpl implements Form_MahasiswaServiceDB{
    private final Sql2o sql2o;
    
    public Form_MahasiswaServiceDBImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void addForm_Mahasiswa(Form_Mahasiswa form_Mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("insert into form_mahasiswa(no_bp, nama_lengkap, jurusan, prodi, tempat_tanggal_lahir, jenis_kelamin, agama, no_telp, alamat) "
                    + "VALUES (:no_bp, :nama_lengkap, :jurusan, :prodi, :tempat_tanggal_lahir, :jenis_kelamin, :agama, :no_telp, :alamat)")
                    .addParameter("no_bp", form_Mahasiswa.getNo_bp())
                    .addParameter("nama_lengkap", form_Mahasiswa.getNama_lengkap())
                    .addParameter("jurusan",form_Mahasiswa.getJurusan())
                    .addParameter("prodi",form_Mahasiswa.getProdi())
                    .addParameter("tempat_tanggal_lahir",form_Mahasiswa.getTempat_tanggal_lahir())
                    .addParameter("jenis_kelamin", form_Mahasiswa.getJenis_kelamin())
                    .addParameter("agama", form_Mahasiswa.getAgama())
                    .addParameter("no_telp", form_Mahasiswa.getNo_telp())
                    .addParameter("alamat", form_Mahasiswa.getAlamat())
                    .executeUpdate();
            conn.commit();
        }
    }

    @Override
    public List<Form_Mahasiswa> getForm_Mahasiswa() {
       try (Connection conn = sql2o.open()) {
            List<Form_Mahasiswa> form_mahasiswa = conn.createQuery("select * from form_mahasiswa")
                    .executeAndFetch(Form_Mahasiswa.class);
            return form_mahasiswa;
        }
    }

    @Override
    public Form_Mahasiswa getForm_Mahasiswa(String no_bp) {
         try (Connection conn = sql2o.open()) {
            Form_Mahasiswa form_Mahasiswa= conn.createQuery("select * from form_mahasiswa where no_bp=:no_bp")
                    .addParameter("no_bp", no_bp)
                    .executeAndFetchFirst(Form_Mahasiswa.class);
            return form_Mahasiswa;
        }
    }

    @Override
    public Form_Mahasiswa editForm_Mahasiswa(Form_Mahasiswa form_Mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("update form_mahasiswa set nama_lengkap=:nama_lengkap,"
                    + "jurusan=:jurusan, prodi=:prodi, tempat_tanggal_lahir=:tempat_tanggal_lahir, jenis_kelamin=:jenis_kelamin, agama=:agama, no_telp=:no_telp, alamat=:alamat where no_bp=:no_bp")
                    .addParameter("no_bp", form_Mahasiswa.getNo_bp())
                    .addParameter("nama_lengkap", form_Mahasiswa.getNama_lengkap())
                    .addParameter("jurusan",form_Mahasiswa.getJurusan())
                    .addParameter("prodi",form_Mahasiswa.getProdi())
                    .addParameter("tempat_tanggal_lahir",form_Mahasiswa.getTempat_tanggal_lahir())
                    .addParameter("jenis_kelamin", form_Mahasiswa.getJenis_kelamin())
                    .addParameter("agama", form_Mahasiswa.getAgama())
                    .addParameter("no_telp", form_Mahasiswa.getNo_telp())
                    .addParameter("alamat", form_Mahasiswa.getAlamat())
                    .executeUpdate();
            conn.commit();
        }
        return form_Mahasiswa;
    }

    @Override
    public void deletedForm_Mahasiswa(String no_bp) {
        try (Connection conn = sql2o.open()) {
            conn.createQuery("delete from form_mahasiswa where no_bp=:no_bp")
                    .addParameter("no_bp", no_bp)
                    .executeUpdate();
        }
    }

    @Override
    public boolean form_MahasiswaExist(String no_bp) {
       try (Connection conn = sql2o.open()) {
            List<Form_Mahasiswa> form_Mahasiswa= conn.createQuery("select * from form_mahasiswa no_bp=:no_bp")
                    .addParameter("no_bp", no_bp)
                    .executeAndFetch(Form_Mahasiswa.class);
            return form_Mahasiswa.size() > 0;
        }
    }
   

    
}
