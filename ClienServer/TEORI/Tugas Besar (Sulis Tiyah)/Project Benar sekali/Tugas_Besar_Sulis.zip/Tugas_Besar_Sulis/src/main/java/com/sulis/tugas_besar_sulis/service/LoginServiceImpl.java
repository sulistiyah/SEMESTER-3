/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.tugas_besar_sulis.service;

import com.sulis.tugas_besar_sulis.model.Login;
import java.util.Collection;
import java.util.HashMap;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class LoginServiceImpl implements LoginService{
    private HashMap<String, Login> loginMap;
    private final Sql2o sql2o;
    
    public LoginServiceImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
        loginMap = new HashMap<>();
        Login login = new Login();
        login.setUsername("Sulistyh_");
        login.setPassword("12345");
        loginMap.put(login.getUsername(), login);
    }

    @Override
    public void addLogin(Login login) {
        try (Connection conn = sql2o.beginTransaction()) {
        loginMap.put(login.getUsername(), login);
        }
    }

    @Override
    public Collection<Login> getLogin() {
       return loginMap.values();
    }

    @Override
    public Login getLogin(String no_bp) {
        return loginMap.get(no_bp);
    }

    @Override
    public Login editLogin(Login login) {
        Login loginEdit = loginMap.get(login.getUsername());
        loginEdit.setPassword(login.getPassword());
        return loginEdit;
    }

    @Override
    public void deletedLogin(String username) {
       loginMap.remove(username);
    }

    @Override
    public boolean loginExist(String username) {
       return loginMap.containsKey(username);
    }

    
    
}
