/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.pcs_2001081002.service;

import com.sulis.pcs_2001081002.model.Gaji;
import com.sulis.pcs_2001081002.model.User;
import java.util.Collection;
import java.util.Objects;
import java.util.HashMap;

/**
 *
 * @author Windows
 */
public class GajiServiceImpl implements GajiService{
    private HashMap<String, Gaji> userMap;
    
    public GajiServiceImpl() {
        userMap = new HashMap<>();
        Gaji gaji = new Gaji();
        gaji.setId("1");
        gaji.setBulan(12);
        gaji.setTahun(2021);
        gaji.setNip("123456789");
        gaji.setNama("Sulis");
        gaji.setGolongan(0);
        gaji.setGajipokok(0);
        gaji.setTunjangan(0);
        gaji.setTunjangan_anak(0);
        gaji.setTunjangan_istri(0);
        gaji.setPotongan(0);
        gaji.setGaji_bersih(0);
        userMap.put(gaji.getId(), gaji);
        
    }

    @Override
    public void addGaji(Gaji gaji) {
        userMap.put(gaji.getId(), gaji);
    }

    @Override
    public Collection<Gaji> getGaji() {
        return userMap.values();
    }

    @Override
    public Gaji getGaji(String id) {
        return userMap.get(id);
    }

    @Override
    public Gaji editGaji(Gaji gaji) {
        Gaji gajiEdit = userMap.get(gaji.getId());
        gajiEdit.setBulan(gaji.getBulan());
        gajiEdit.setTahun(gaji.getTahun());
        gajiEdit.setNip(gaji.getNip());
        gajiEdit.setNama(gaji.getNama());
        gajiEdit.setGolongan(gaji.getGolongan());
        gajiEdit.setGajipokok(gaji.getGajipokok());
        gajiEdit.setTunjangan(gaji.getTunjangan());
        gajiEdit.setTunjangan_anak(gaji.getTunjangan_anak());
        gajiEdit.setTunjangan_istri(gaji.getTunjangan_istri());
        gajiEdit.setPotongan(gaji.getPotongan());
        gajiEdit.setGaji_bersih(gaji.getGaji_bersih());
        return gajiEdit;
    }

    @Override
    public void deleteGaji(String id) {
       userMap.remove(id);
    }

    @Override
    public boolean gajiExist(String id) {
        return userMap.containsKey(id);
    }

    @Override
    public Object getgaji() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
}
