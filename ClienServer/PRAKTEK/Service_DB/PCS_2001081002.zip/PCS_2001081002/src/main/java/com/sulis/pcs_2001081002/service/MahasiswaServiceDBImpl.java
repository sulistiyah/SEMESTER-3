/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.pcs_2001081002.service;

import com.sulis.pcs_2001081002.model.Mahasiswa;
import java.util.List;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class MahasiswaServiceDBImpl implements MahasiswaServiceDB{
    
    private final Sql2o sql2o;
    
    public MahasiswaServiceDBImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public void addMahasiswa(Mahasiswa mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("insert into mahasiswa(id, no_bp, nama, alamat, jenis_kelamin) "
                    + "VALUES (:id, :no_bp, :nama, :alamat, :jenis_kelamin)")
                    .addParameter("id", mahasiswa.getId())
                    .addParameter("no_bp", mahasiswa.getNo_bp())
                    .addParameter("nama", mahasiswa.getNama())
                    .addParameter("alamat", mahasiswa.getAlamat())
                    .addParameter("jenis_kelamin", mahasiswa.getJenis_kelamin())
                    .executeUpdate();
            conn.commit();
        }
    }

    @Override
    public List<Mahasiswa> getMahasiswa() {
       try (Connection conn = sql2o.open()) {
            List<Mahasiswa> mahasiswa = conn.createQuery("select * from mahasiswa")
                    .executeAndFetch(Mahasiswa.class);
            return mahasiswa;
        }
    }

    @Override
    public Mahasiswa getMahasiswa(String id) {
         try (Connection conn = sql2o.open()) {
            Mahasiswa mahasiswa= conn.createQuery("select * from mahasiswa where id=:id")
                    .addParameter("id", id)
                    .executeAndFetchFirst(Mahasiswa.class);
            return mahasiswa;
        }
    }

    @Override
    public Mahasiswa editMahasiswa(Mahasiswa mahasiswa) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("update mahasiswa set no_bp=:no_bp,"
                    + "nama=:nama, alamat=:alamat,jenis_kelamin=:jenis_kelamin where id=:id")
                   .addParameter("id", mahasiswa.getId())
                    .addParameter("no_bp", mahasiswa.getNo_bp())
                    .addParameter("nama", mahasiswa.getNama())
                    .addParameter("alamat", mahasiswa.getAlamat())
                    .addParameter("jenis_kelamin", mahasiswa.getJenis_kelamin())
                    .executeUpdate();
            conn.commit();
        }
        return mahasiswa;
    }

    @Override
    public void deletedMahasiswa(String id) {
        try (Connection conn = sql2o.open()) {
            conn.createQuery("delete from mahasiswa where id=:id")
                    .addParameter("id", id)
                    .executeUpdate();
        }
    }

    @Override
    public boolean mahasiswaExist(String id) {
       try (Connection conn = sql2o.open()) {
            List<Mahasiswa> mahasiswa = conn.createQuery("select * from mahasiswa where id=:id")
                    .addParameter("id", id)
                    .executeAndFetch(Mahasiswa.class);
            return mahasiswa.size() > 0;
        }
    }
   


}