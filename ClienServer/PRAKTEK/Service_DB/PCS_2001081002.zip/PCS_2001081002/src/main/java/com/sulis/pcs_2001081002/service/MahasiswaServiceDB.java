/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.pcs_2001081002.service;

import com.sulis.pcs_2001081002.model.Mahasiswa;

import java.util.List;

/**
 *
 * @author Sulis Tiyah
 */
public interface MahasiswaServiceDB {
    public void addMahasiswa (Mahasiswa mahasiswa);
    public List<Mahasiswa> getMahasiswa();
    public Mahasiswa getMahasiswa(String id);
    public Mahasiswa editMahasiswa(Mahasiswa mahasiswa);
    public void deletedMahasiswa(String id);
    public boolean mahasiswaExist(String id);

}
