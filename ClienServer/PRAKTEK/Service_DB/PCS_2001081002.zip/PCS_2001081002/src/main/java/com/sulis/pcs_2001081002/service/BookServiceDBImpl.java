/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.pcs_2001081002.service;

import com.sulis.pcs_2001081002.model.Book;
import java.util.List;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Windows
 */
public class BookServiceDBImpl implements BookServiceDB{
    private final Sql2o sql2o;
    
    public BookServiceDBImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

 
    @Override
    public void addBook(Book book) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("insert into book(id, kode, judul, pengarang, penerbit, tahunTerbit) "
                    + "VALUES (:id, :kode, :judul, :pengarang, :penerbit, :tahunTerbit)")
                    .addParameter("id", book.getId())
                    .addParameter("kode", book.getKode())
                    .addParameter("judul", book.getJudul())
                    .addParameter("pengarang", book.getPengarang())
                    .addParameter("penerbit", book.getPenerbit())
                    .addParameter("tahunTerbit", book.getTahunTerbit())
                    .executeUpdate();
            conn.commit();
        }
       
    }

    @Override
    public List<Book> getBook() {
       try (Connection conn = sql2o.open()) {
            List<Book> book = conn.createQuery("select * from book")
                    .executeAndFetch(Book.class);
            return book;
        }
    }

    @Override
    public Book getBook(String id) {
       try (Connection conn = sql2o.open()) {
            Book book = conn.createQuery("select * from book where id=:id")
                    .addParameter("id", id)
                    .executeAndFetchFirst(Book.class);
            return book;
        }
    }

    @Override
    public Book editBook(Book book) {
      try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("update book set kode=:kode,"
                    + "judul=:judul,pengarang=:pengarang,penerbit=:penerbit,tahunTerbit=:tahunTerbit where id=:id")
                    .addParameter("id", book.getId())
                    .addParameter("kode", book.getKode())
                    .addParameter("judul", book.getJudul())
                    .addParameter("pengarang", book.getPengarang())
                    .addParameter("penerbit", book.getPenerbit())
                    .addParameter("tahunTerbit", book.getTahunTerbit())
                    .executeUpdate();
            conn.commit();
        }
        return book;
    }

    @Override
    public void deleteBook(String id) {
        try (Connection conn = sql2o.open()) {
            conn.createQuery("delete from book where id=:id")
                    .addParameter("id", id)
                    .executeUpdate();
        }
    }

    @Override
    public boolean bookExist(String id) {
       try (Connection conn = sql2o.open()) {
            List<Book> book = conn.createQuery("select * from book where id=:id")
                    .addParameter("id", id)
                    .executeAndFetch(Book.class);
            return book.size() > 0;
        }
    }
    
}
