/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.pcs_2001081002;

import com.google.gson.Gson;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import com.sulis.pcs_2001081002.model.Book;
import com.sulis.pcs_2001081002.model.User;
import com.sulis.pcs_2001081002.model.Mahasiswa;
import com.sulis.pcs_2001081002.response.StandardResponse;
import com.sulis.pcs_2001081002.response.StatusResponse;
import com.sulis.pcs_2001081002.service.BookServiceDB;
import com.sulis.pcs_2001081002.service.BookServiceDBImpl;
import com.sulis.pcs_2001081002.service.UserServiceDB;
import com.sulis.pcs_2001081002.service.UserServiceDBImpl;
import com.sulis.pcs_2001081002.service.MahasiswaServiceDB;
import com.sulis.pcs_2001081002.service.MahasiswaServiceDBImpl;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.sql2o.Sql2o;
import static spark.Spark.delete;
import static spark.Spark.get;
import static spark.Spark.post;
import static spark.Spark.put;



/**
 *
 * @author Windows
 */
public class SparkRestDB {
    public static void main(String[] args) {
        try {
            Sql2o sql2o = new Sql2o(getDataSource());
            final UserServiceDB userService = new UserServiceDBImpl(sql2o);

            post("/user", (request, response) -> {
                response.type("application/json");

                User user = new Gson().fromJson(request.body(), User.class);
                userService.addUser(user);

                return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
            });

            get("/user", (request, response) -> {
                response.status(200);
                response.type("application/json");
                return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS, new Gson().toJsonTree(userService.getUsers())));
            });
            
            get("/user/:id", (request, response) -> {
                response.type("application/json");
                return new Gson().toJson(
                        new StandardResponse(StatusResponse.SUCCESS,
                                new Gson().toJsonTree(
                                        userService.getUser(request.params(":id"))
                                )
                        )
                );
            });
            
            put("/user/:id", (request, response) -> {
                response.type("application/json");
                User toEdit = new Gson().fromJson(request.body(), User.class);
                User editedUser = userService.editUser(toEdit);
                if (editedUser != null) {
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.SUCCESS,
                                    new Gson().toJsonTree(editedUser)));
                } else {
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.ERROR,
                                    new Gson().toJson("User not found or error in edit")));
                }
            });

            delete("/user/:id", (request, response) -> {
                response.type("application/json");
                userService.deleteUser(request.params(":id"));
                return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS, "user deleted"));
            });
            
            
            final MahasiswaServiceDB mahasiswaService = new MahasiswaServiceDBImpl(sql2o);

            post("/mahasiswa", (request, response) -> {
            response.type("application/json");
            
            Mahasiswa mahasiswa = new Gson().fromJson(request.body(), Mahasiswa.class);
            mahasiswaService.addMahasiswa(mahasiswa);
            
            return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
            });
        
            get("/mahasiswa", (request, response) -> {
                response.type("application/json");
                return new Gson().toJson(
                        new StandardResponse(StatusResponse.SUCCESS,new Gson().toJsonTree(mahasiswaService.getMahasiswa())));
            });
        
            
        
        final BookServiceDB bookService = new BookServiceDBImpl(sql2o);
        
            post("/book", (request, response) -> {
                response.type("application/json");

                Book book = new Gson().fromJson(request.body(), Book.class);
                bookService.addBook(book);

                return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
            });

            get("/book", (request, response) -> {
                response.status(200);
                response.type("application/json");
                return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS, new Gson().toJsonTree(bookService.getBook())));
            });
            
            get("/book/:id", (request, response) -> {
                response.type("application/json");
                return new Gson().toJson(
                        new StandardResponse(StatusResponse.SUCCESS,
                                new Gson().toJsonTree(
                                        bookService.getBook(request.params(":id"))
                                )
                        )
                );
            });
            
            put("/book/:id", (request, response) -> {
                response.type("application/json");
                Book toEdit = new Gson().fromJson(request.body(), Book.class);
                Book editedBook = bookService.editBook(toEdit);
                if (editedBook != null) {
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.SUCCESS,
                                    new Gson().toJsonTree(editedBook)));
                } else {
                    return new Gson().toJson(
                            new StandardResponse(StatusResponse.ERROR,
                                    new Gson().toJson("Book not found or error in edit")));
                }
            });

            delete("/book/:id", (request, response) -> {
                response.type("application/json");
                bookService.deleteBook(request.params(":id"));
                return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS, "Book deleted"));
            });
            
        } catch (SQLException ex) {
            Logger.getLogger(SparkRestDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static DataSource getDataSource() throws SQLException {
        MysqlDataSource dataSource = new MysqlDataSource();
        dataSource.setDatabaseName("pcs_2001081002");
        dataSource.setServerName("localhost");
        dataSource.setPort(3306);
        dataSource.setUser("root");
        dataSource.setPassword("");
        dataSource.setServerTimezone("UTC");
        return dataSource;
    }
}

