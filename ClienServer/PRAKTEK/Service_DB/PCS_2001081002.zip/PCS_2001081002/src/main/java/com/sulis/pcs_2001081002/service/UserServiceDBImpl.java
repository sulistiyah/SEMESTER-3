/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.pcs_2001081002.service;

import com.sulis.pcs_2001081002.model.User;
import java.util.List;
import org.sql2o.Connection;
import org.sql2o.Sql2o;

/**
 *
 * @author Sulis Tiyah
 */
public class UserServiceDBImpl implements UserServiceDB{
    
    private final Sql2o sql2o;
    
    public UserServiceDBImpl(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
     public void addUser(User user) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("insert into user(id, firstName, lastName,email) "
                    + "VALUES (:id, :firstName, :lastName, :email)")
                    .addParameter("id", user.getId())
                    .addParameter("firstName", user.getFirstName())
                    .addParameter("lastName", user.getLastName())
                    .addParameter("email", user.getEmail())
                    .executeUpdate();
            conn.commit();
        }
    }

    @Override
    public List<User> getUsers() {
        try (Connection conn = sql2o.open()) {
            List<User> users = conn.createQuery("select * from user")
                    .executeAndFetch(User.class);
            return users;
        }
    }

    @Override
    public User getUser(String id) {
        try (Connection conn = sql2o.open()) {
            User user = conn.createQuery("select * from user where id=:id")
                    .addParameter("id", id)
                    .executeAndFetchFirst(User.class);
            return user;
        }
    }

    @Override
    public User editUser(User user) {
        try (Connection conn = sql2o.beginTransaction()) {
            conn.createQuery("update user set firstName=:firstName,"
                    + "lastName=:lastName,email=:email where id=:id")
                    .addParameter("id", user.getId())
                    .addParameter("firstName", user.getFirstName())
                    .addParameter("lastName", user.getLastName())
                    .addParameter("email", user.getEmail())
                    .executeUpdate();
            conn.commit();
        }
        return user;
    }

    @Override
    public void deleteUser(String id) {
        try (Connection conn = sql2o.open()) {
            conn.createQuery("delete from user where id=:id")
                    .addParameter("id", id)
                    .executeUpdate();
        }
    }

    @Override
    public boolean userExist(String id) {
        try (Connection conn = sql2o.open()) {
            List<User> users = conn.createQuery("select * from user where id=:id")
                    .addParameter("id", id)
                    .executeAndFetch(User.class);
            return users.size() > 0;
        }
    
    }
    
}
