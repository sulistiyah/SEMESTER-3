/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sulis.pcs_2001081002;

import com.google.gson.Gson;
import com.sulis.pcs_2001081002.model.User;
import com.sulis.pcs_2001081002.model.Book;
import com.sulis.pcs_2001081002.model.Mahasiswa;
import com.sulis.pcs_2001081002.response.StandardResponse;
import com.sulis.pcs_2001081002.response.StatusResponse;
import com.sulis.pcs_2001081002.service.UserService;
import com.sulis.pcs_2001081002.service.UserServiceImpl;
import com.sulis.pcs_2001081002.service.BookService;
import com.sulis.pcs_2001081002.service.BookServiceImpl;
import com.sulis.pcs_2001081002.service.MahasiswaService;
import com.sulis.pcs_2001081002.service.MahasiswaServiceImpl;
import static spark.Spark.get;
import static spark.Spark.post;

/**
 *
 * @author Sulis Tiyah
 */
public class SparkRestExample {
  public static void main(String[] args) {
        final UserService userService = new UserServiceImpl();
        
        post("/users", (request,response) -> {
            response.type("application/json");
            User user = new Gson().fromJson(request.body(), User.class);
            userService.addUser(user);
            return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));  
        });
        get("/users", (request, response) -> {
            response.type("application/json");
            return new Gson().toJson(
                    new StandardResponse(
                            StatusResponse.SUCCESS,
                            new Gson().toJsonTree(userService.getUsers())
                    )
            );
        });
        
        final BookService bookService = new BookServiceImpl() {};
              
        post("/book", (request, response) -> {
            response.type("application/json");
            Book book = new Gson().fromJson(request.body(), Book.class);
            bookService.addBook(book);
            return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
        });
        
        get("/book", (request, response) -> {
            response.type("application/json");
            return new Gson().toJson(
                    new StandardResponse(
                            StatusResponse.SUCCESS,
                               new Gson().toJsonTree(
                                       bookService.getBook()
                               )
                    )
            );
        });
        
        final MahasiswaService mahasiswaService = new MahasiswaServiceImpl() {};
              
        post("/mahasiswa", (request, response) -> {
            response.type("application/json");
            Mahasiswa mahasiswa = new Gson().fromJson(request.body(), Mahasiswa.class);
            mahasiswaService.addMahasiswa(mahasiswa);
            return new Gson().toJson(new StandardResponse(StatusResponse.SUCCESS));
        });
        
        get("/mahasiswa", (request, response) -> {
            response.type("application/json");
            return new Gson().toJson(
                    new StandardResponse(
                            StatusResponse.SUCCESS,
                               new Gson().toJsonTree(
                                       mahasiswaService.getMahasiswa()
                               )
                    )
            );
        });
            
          
    }
}